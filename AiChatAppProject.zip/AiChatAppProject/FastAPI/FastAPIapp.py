from fastapi import FastAPI
from pydantic import BaseModel
import sqlite3
import requests
import json
import re
import os
from langchain_ollama import OllamaLLM
from langchain.chains import create_sql_query_chain
from langchain_community.utilities import SQLDatabase
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
import logging
from langchain.callbacks import StdOutCallbackHandler

# Initialize FastAPI app
app = FastAPI()

# Initialize logging
logging.basicConfig(level=logging.INFO, format="%(message)s")
handler = StdOutCallbackHandler()
logger = logging.getLogger("FastAPIapp")

# Defines the request schema 
class QueryRequest(BaseModel):
    prompt: str

# Path to your SQLite database
# Make sure to change this path to your actual database path
#DB_PATH = r"C:\Users\P\OneDrive\Documents\AiChatAppProject\SQLiteDB\thrombosis_prediction\thrombosis_prediction.sqlite"

# Get the base directory where this FastAPI script is located
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# SQLite path relative to project
DB_PATH = os.path.join(BASE_DIR, "..", "SQLiteDB", "thrombosis_prediction", "thrombosis_prediction.sqlite")

# GUI path (if needed elsewhere)
GUI_PATH = os.path.join(BASE_DIR, "..", "GUI", "FivosChatbotGUI", "bin", "Debug", "FivosChatbotGUI.exe")


# Creates the SQL lite connection
connection = sqlite3.connect(DB_PATH, check_same_thread=False)

# LangChain database wrapper
#db = SQLDatabase.from_uri(f"sqlite:///{DB_PATH}")

@app.get("/ping")
def ping():
    print("Pinged!")
    return {"status": "ok"}

# Initialize LangChain model
llm = OllamaLLM(model="adhishtanaka/llama_3.2_1b-SQL")
#adhishtanaka/llama_3.2_1b-SQL

def get_schema():
    cur = connection.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = cur.fetchall()
    
    schema = {}
    for (table,) in tables:
        cur.execute(f"PRAGMA table_info({table});")
        columns = cur.fetchall()
        schema[table] = [f"{col[1]} ({col[2]})" for col in columns]
    cur.close()
    return json.dumps(schema, indent=2)


def extract_sql_query(ai_text: str) -> str:

    # 🧹 Clean common formatting junk
    ai_text = (
        ai_text.replace("```sql", "")
        .replace("```", "")
        .replace("SQL:", "")
        .replace("SQL", "")
        .replace("Here’s your SQL:", "")
        .replace("Query:", "")
        .replace("Here's your SQL:", "")
        .strip()
    )

    # 🧠 Try to match SELECT first
    matches = re.findall(r"\bSELECT\b[\s\S]*?;", ai_text, flags=re.IGNORECASE)

    # 🧩 If SELECT not found, try other SQL commands
    if not matches:
        matches = re.findall(r"(CREATE|INSERT|UPDATE|DELETE)[\s\S]*?;", ai_text, flags=re.IGNORECASE)

    # 🪄 Final fallback for unusual formatting
    if not matches:
        matches = re.findall(r"SELECT.*?;", ai_text, flags=re.IGNORECASE | re.DOTALL)

    # ✅ Return first clean match or fallback to entire text
    sql_query = matches[0].strip() if matches else ai_text.strip()

    print(f"✅ Generated SQL:\n{sql_query}\n")
    return sql_query


@app.post("/ask")
def ask(request: QueryRequest):
    prompt = request.prompt
    schema = get_schema()

    print("\n🧠 [1] Generating SQL query using LangChain & tinyllama...\n")

    #adhishtanaka/llama_3.2_1b-SQL
    #with open("train_gold.sql", "r", encoding="utf-8") as file: golden_set = file.read()


    ollama_payload = {
        "model": "adhishtanaka/llama_3.2_1b-SQL",
        "prompt": (
            "You are an expert SQLite query generator. " + 
            "Use ONLY the tables and columns provided below. " +
            "DO NOT GENERATE COLUMN NAMES OR TABLES \n" +
            "ALL OF THE TABLES AND COLUMN NAMES ARE PROVIDED IN THE PROMPT \n" +
            "There is a Patient table \n" +
            "There is an Examination table \n" +
            "There is a Laboratory table \n" +
            "There are no other tables than the above three. " +
            "Do NOT create new tables or guess column names. \n\n" +
            "ONLY CREATE QUERIES FROM THE TABLES AND COLUMN NAMES PROVIDED \n" +
            #"This is an example SQL Query: " +
            #"SELECT CAST(SUM(CASE WHEN Admission = '+' THEN 1 ELSE 0 END) AS REAL) * 100 / SUM(CASE WHEN Admission = '-' THEN 1 ELSE 0 END) FROM Patient WHERE SEX = 'M'" + "\n" +
            "Your response should ONLY be based on the given context and follow the response guidelines and format instructions below." +
            "=== Response Guidelines: \n" +
            "- If the provided context contains sufficient information to answer the question," +
            " generate the appropriate SQL query to retrieve the required data. \n" +
            " DO NOT GENERATE COLUMN NAMES OR TABLES \n" +
            " Do NOT create new tables or guess column names. \n\n" +
            "- If the provided context does not contain sufficient information to answer the question," +
            " please explain why in cannot be generated. \n" +
            "- Focus solely on the provided database schema description. \n" +
            "- Use standard SQL syntax compatible with SQLite. \n" +
            "- Ensure all table aliases are followed by a period when referencing columns. \n" +
            "- Ensure the query is efficient and optimized for performance. \n\n" +
            "=== DATABASE SCHEMA ===\n" +
            #f"{schema}\n" +
            "These are the only tables \n" +
            "There is a Patient table \n" +
            "There is an Examination table \n" +
            "There is a Laboratory table \n" +
            "DO NOT CREATE COLUMN NAMES OR TABLES \n" +
            "ALL OF THE TABLES AND COLUMN NAMES ARE PROVIDED IN THE PROMPT \n" +
            "Use ONLY the tables and columns provided below. \n" +
            "Do NOT create new tables or guess column names \n" +
            "All of the table names and column names have been provided, use those \n" +
            "Patient Table Description: \n" +
            "These are the Patient table column names: ID (primary key), SEX, Birthday, Description, 'First Date', Admission, Diagnosis"
            #Patient ( ID INTEGER default 0 not null primary key, SEX TEXT null, Birthday DATE null, Description DATE null, `First Date` DATE null, Admission TEXT null, Diagnosis TEXT null )" + "\n\n" +
            "When accessing the Patient table ONLY use the above column names \n" +
            "When accessing the column names they are case sensitive, only use the case provided \n" +
            "Examination Table Description: \n" +
            "These are the Examination table column names: ID, 'Examination Date', 'aCL IgG', 'aCL IgM', ANA, 'ANA Pattern', 'aCL IgA', Diagnosis, KCT, RVVT, LAC, Symptoms, Thrombosis, foreign key (ID) referneces Patient ID"
            #Examination ( ID INTEGER null, `Examination Date` DATE null, `aCL IgG` REAL null, `aCL IgM` REAL null, ANA INTEGER null, `ANA Pattern` TEXT null, `aCL IgA` INTEGER null, Diagnosis TEXT null, KCT TEXT null, RVVT TEXT null, LAC TEXT null, Symptoms TEXT null, Thrombosis INTEGER null, foreign key (ID) references Patient (ID) on update cascade on delete cascade )" + "\n\n" +
            "When accessing the Examination table ONLY use the above column names \n" +
            "When accessing the column names they are case sensitive, only use the case provided \n" +
            "Laboratory Table Description: \n" +
            "These are the Laboratory table column names: ID, Date, GOT, GPT, LDH, ALP, TP, ALB, UA, UN, CRE, 'T-BIL', 'T-CHO', TG, CPK, GLU, WBC, RBC, HGB, HCT, PLT, PT, APTT, FG, PIC, TAT, TAT2, 'U-PRO', IGG, IGA, IGM, CRP, RA, RF, C3, C4, RNP, SM, SC170, SSA, SSB, CENTROMEA, DNA, 'DNA-II', primary key (ID, Date), forign key (ID) references Patient ID"
            #Laboratory ( ID INTEGER default 0 not null, Date DATE default '0000-00-00' not null, GOT INTEGER null, GPT INTEGER null, LDH INTEGER null, ALP INTEGER null, TP REAL null, ALB REAL null, UA REAL null, UN INTEGER null, CRE REAL null, `T-BIL` REAL null, `T-CHO` INTEGER null, TG INTEGER null, CPK INTEGER null, GLU INTEGER null, WBC REAL null, RBC REAL null, HGB REAL null, HCT REAL null, PLT INTEGER null, PT REAL null, APTT INTEGER null, FG REAL null, PIC INTEGER null, TAT INTEGER null, TAT2 INTEGER null, `U-PRO` TEXT null, IGG INTEGER null, IGA INTEGER null, IGM INTEGER null, CRP TEXT null, RA TEXT null, RF TEXT null, C3 INTEGER null, C4 INTEGER null, RNP TEXT null, SM TEXT null, SC170 TEXT null, SSA TEXT null, SSB TEXT null, CENTROMEA TEXT null, DNA TEXT null, `DNA-II` INTEGER null, primary key (ID, Date), foreign key (ID) references Patient (ID) on update cascade on delete cascade )" + "\n" +
            "When accessing the Laboratory table ONLY use the above column names \n" +
            "When accessing the column names they are case sensitive, only use the case provided \n" +
            "These are the only tables \n" +
            "Do NOT create new tables or guess column names \n" +
            "All of the table names and column names have been provided, use those \n" +
            "THE COLUMN NAMES AND TABLE NAMES HAVE BEEN PROVIDED \n" +
            "ONLY USE THE COLUMN NAMES AND TABLE NAMES THAT HAVE BEEN PROVIDED \n" +
            "THE COLUMN NAMES FOR THE Patient table, Examination table, and Laboratory table ARE LISTED ABOVE \n" +
            "ONLY USE THOSE COLUMN NAMES TO ACCESS THE TABLES PROVIDED \n" +
            "ONLY CREATE QUERIES FROM THE TABLES AND COLUMN NAMES PROVIDED \n" +
            #"This is an example SQL Query: " +
            #"SELECT CAST(SUM(CASE WHEN Admission = '+' THEN 1 ELSE 0 END) AS REAL) * 100 / SUM(CASE WHEN Admission = '-' THEN 1 ELSE 0 END) FROM Patient WHERE SEX = 'M'" + "\n" +
            #"Use the above example query to help write other SQL Queries" +
            "========================\n\n" +
            #"=== GOLDEN SET EXAMPLES ===\n" +
            #"You may use the golden set below as reference examples for query style and structure.\n" +
            #f"{golden_set}\n" +
            "============================\n\n" +
            "=== Response Guidelines: \n" +
            "- If the provided context contains sufficient information to answer the question," +
            " generate the appropriate SQL query to retrieve the required data. \n" +
            "- If the provided context does not contain sufficient information to answer the question," +
            " please explain why in cannot be generated. \n" +
            "- Focus solely on the provided database schema description. \n" +
            "- Use standard SQL syntax compatible with SQLite. \n" +
            "- Ensure all table aliases are followed by a period when referencing columns. \n" +
            "- Ensure the query is efficient and optimized for performance. \n\n" +
            "============================\n\n" +
            "User Question:\n" +
            f"{prompt}\n\n" +
            "Rules:\n" +
            "1. Use only valid SQLite syntax.\n" +
            "2. Return exactly ONE SQL query, ending with a semicolon.\n" +
            "3. Do NOT include explanations, markdown, or commentary.\n" +
            "4. Table names are case-sensitive — use exactly as shown.\n\n" +
            "DO NOT CREATE COLUMN NAMES OR TABLES \n" +
            "ALL OF THE TABLES AND COLUMN NAMES ARE PROVIDED IN THE PROMPT \n" +
            "Patient Table Description: \n" +
            "These are the Patient table column names: ID (primary key), SEX, Birthday, Description, 'First Date', Admission, Diagnosis"
            #Patient ( ID INTEGER default 0 not null primary key, SEX TEXT null, Birthday DATE null, Description DATE null, `First Date` DATE null, Admission TEXT null, Diagnosis TEXT null )" + "\n\n" +
            "Examination Table Description: \n" +
            "These are the Examination table column names: ID, 'Examination Date', 'aCL IgG', 'aCL IgM', ANA, 'ANA Pattern', 'aCL IgA', Diagnosis, KCT, RVVT, LAC, Symptoms, Thrombosis, foreign key (ID) referneces Patient ID"
            #Examination ( ID INTEGER null, `Examination Date` DATE null, `aCL IgG` REAL null, `aCL IgM` REAL null, ANA INTEGER null, `ANA Pattern` TEXT null, `aCL IgA` INTEGER null, Diagnosis TEXT null, KCT TEXT null, RVVT TEXT null, LAC TEXT null, Symptoms TEXT null, Thrombosis INTEGER null, foreign key (ID) references Patient (ID) on update cascade on delete cascade )" + "\n\n" +
            "Laboratory Table Description: \n" +
            "These are the Laboratory table column names: ID, Date, GOT, GPT, LDH, ALP, TP, ALB, UA, UN, CRE, 'T-BIL', 'T-CHO', TG, CPK, GLU, WBC, RBC, HGB, HCT, PLT, PT, APTT, FG, PIC, TAT, TAT2, 'U-PRO', IGG, IGA, IGM, CRP, RA, RF, C3, C4, RNP, SM, SC170, SSA, SSB, CENTROMEA, DNA, 'DNA-II', primary key (ID, Date), forign key (ID) references Patient ID"
            #Laboratory ( ID INTEGER default 0 not null, Date DATE default '0000-00-00' not null, GOT INTEGER null, GPT INTEGER null, LDH INTEGER null, ALP INTEGER null, TP REAL null, ALB REAL null, UA REAL null, UN INTEGER null, CRE REAL null, `T-BIL` REAL null, `T-CHO` INTEGER null, TG INTEGER null, CPK INTEGER null, GLU INTEGER null, WBC REAL null, RBC REAL null, HGB REAL null, HCT REAL null, PLT INTEGER null, PT REAL null, APTT INTEGER null, FG REAL null, PIC INTEGER null, TAT INTEGER null, TAT2 INTEGER null, `U-PRO` TEXT null, IGG INTEGER null, IGA INTEGER null, IGM INTEGER null, CRP TEXT null, RA TEXT null, RF TEXT null, C3 INTEGER null, C4 INTEGER null, RNP TEXT null, SM TEXT null, SC170 TEXT null, SSA TEXT null, SSB TEXT null, CENTROMEA TEXT null, DNA TEXT null, `DNA-II` INTEGER null, primary key (ID, Date), foreign key (ID) references Patient (ID) on update cascade on delete cascade )" + "\n" +
            "These are the only tables \n" +
            "Do NOT create new tables or guess column names \n" +
            "All of the table names and column names have been provided, use those \n" +
            "ONLY CREATE QUERIES FROM THE TABLES AND COLUMN NAMES PROVIDED \n" +
            #"This is an example SQL Query: " +
            #"SELECT CAST(SUM(CASE WHEN Admission = '+' THEN 1 ELSE 0 END) AS REAL) * 100 / SUM(CASE WHEN Admission = '-' THEN 1 ELSE 0 END) FROM Patient WHERE SEX = 'M'" + "\n" +
            #"Use the above example query to help write other SQL Queries" +
            "Output:\n" +
            "Only the SQL query, nothing else."
        ),
        "stream": False
    }

    '''
    prompt_template = (
    'You are an expert database developer. \n\n' +
    'Please help generate a SQL query to answer the question. ' +
    'Your response should ONLY be based on the given context and ' +
    'follow the response guidelines and format instructions below. \n\n' +
    '=== Database Schema Description: \n'+
    'Patient Table Description: \n' +
    Patient_dd.to_string(index=False) + '\n\n' +
    'Examination Table Description: \n' +
    Examination_dd.to_string(index=False) + '\n\n' +
    'Laboratory Table Description: \n' +
    Laboratory_dd.to_string(index=False) + '\n\n' +
    '=== Response Guidelines: \n' +
    '- If the provided context contains sufficient information to answer the question,' +
    ' generate the appropriate SQL query to retrieve the required data. \n' +
    '- If the provided context does not contain sufficient information to answer the question,' +
    ' please explain why in cannot be generated. \n' +
    '- Focus solely on the provided database schema description. \n' +
    '- Use standard SQL syntax compatible with SQLite. \n' +
    '- Ensure all table aliases are followed by a period when referencing columns. \n' +
    '- Ensure the query is efficient and optimized for performance. \n\n' +
    '=== Question: \n' +
    # 'How many patients are there in the Patient table?\n'
    # 'Find all patients with uric acid above normal levels in their most recent laboratory test.' +
    # '  Uric acid range is dependent on sex, so be sure to include sex when determining if the level is above normal.' +
    # '  Return the ID, DOB, sex, lab date, and uric acid level.'
    gold_set.iloc[0]['question'] + '\n\n' +
    gold_set.iloc[0]['evidence'] + '\n'
    )
print("Question:", gold_set.iloc[0]['question'])
print("Evidence:", gold_set.iloc[0]['evidence'])
    '''

    try:
        response = requests.post(
            "http://localhost:11434/api/generate",
            json=ollama_payload,
            timeout=180  # ⏱️ 180-second timeout for Ollama
        )
        response.raise_for_status()

        ai_text = response.json().get("response", "").strip()
        print("🧠 Raw model output:\n", ai_text)

        # ✅ Use extract_sql_query function to extract SQL
        sql_query = extract_sql_query(ai_text)
        print("🧠 Cleaned SQL Query:", sql_query)

        # ✅ Execute cleaned query
        try:
            print("⚙️ [2] Executing query on SQLite database...")
            cur = connection.cursor()
            cur.execute(sql_query)
            rows = cur.fetchall()
            cur.close()
            results = [list(row) for row in rows]
            print(f"✅ Retrieved {len(results)} rows.\n")

        except Exception as e:
            return {"error": str(e), "sql": sql_query}

        # ✅ [3] Generate natural-language summary using LangChain
        print("💬 [3] Generating natural-language summary using LangChain...\n")
        llm = OllamaLLM(model="tinyllama")  # small, more natural-text focused model
        summary_prompt = PromptTemplate(
            input_variables=["query", "results"],
            template=(
                "You are a helpful assistant. Given the SQL query:\n{query}\n"
                "and its results:\n{results}\n"
                "summarize the findings in clear, natural English."
            ),
        )

        summary_chain = LLMChain(llm=llm, prompt=summary_prompt)
        summary = summary_chain.run({"query": sql_query, "results": results})
        print(f"🧾 [4] Summary generated:\n{summary}\n")

        # ✅ [4] Return all data (SQL, Results, and Summary)
        response_data = {
            "sql": sql_query,
            "result": results,
            "summary": summary
        }

        print("📤 Sending to GUI:", response_data)
        return response_data

    except requests.Timeout:
        return {"error": "Ollama request timed out after 180 seconds."}
    except Exception as e:
        return {"error": str(e)}



# How to run the app:    
# Ensure you have FastAPI, Uvicorn, Langchain, Requests and Pydantic installed:
# In the console: python -m pip install langchain langchain-community fastapi uvicorn requests pydantic
# Install the Ollama Langchain integration: pip install -U langchain-ollama
# In the console: python -m pip install "uvicorn[standard]"
# Ensure you have a SQLite database that matches the name in the code (e.g., ChatAppDB.db or modify the code to match your database name).
# Ensure you have Ollama running locally with the correct model:
# In a terminal: ollama serve
# In another terminal (ensures you're using the right model): ollama pull (model name)
# To run the app, use the command in another terminal (make sure to cd to your folder): uvicorn FastAPIapp:app --reload
# After running this, FastAPI will be available at http://127.0.0.1:8000    